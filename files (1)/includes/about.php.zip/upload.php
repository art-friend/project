<?php 
require_once "config.php";
  
if(isset($_POST['submit'])){
     $fileExistsFlag = 0; 
     $fileName = $_FILES['img']['name'];
     /* 
     *    Checking whether the file already exists in the destination folder 
     
     $query = "SELECT * FROM users WHERE 'user_id'=9";     
     $result = $db->query($query) or die("Error : ".mysqli_error($db));
while($row = mysqli_fetch_array($result)) {
      if($row['img'] == $fileName) {
               $fileExistsFlag = 1;
          }          
     }*/
     /*
     *    If file is not present in the destination folder
     */
if($fileExistsFlag == 0) { 
          $target = "files/";          
          $fileTarget = $target.$fileName;     
          $tempFileName = $_FILES["img"]["tmp_name"];
          $result = move_uploaded_file($tempFileName,$fileTarget);
     /*
     *    If file was successfully uploaded in the destination folder
     */
if($result) { 
          echo "Your file <html><b><i>".$fileName."</i></b></html> has been successfully uploaded";          
          $query = "INSERT INTO drawings (file_path) VALUES ('$fileTarget')";
          $db->query($query) or die("Error : ".mysqli_error($db));               
          }
else {               
          echo "Sorry !!! There was an error in uploading your file";               
          }
          mysqli_close($db);
     }
     /*
     *    If file is already present in the destination folder
     */
else {
          echo "File <html><b><i>".$fileName."</i></b></html> already exists in your folder. Please rename the file and try again.";
          mysqli_close($db);
     } 
 }
 ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="/CSS/style.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Upload a drawing</title>
	

</head>
	<body dir="rtl">
	<header class="col-12">
            <a href="index.php" target="_parent"><img id="logo" src="../CSS\pics\logo.png" /></a>

				
			<script>
                function menuFunction() {
                    var x = document.getElementById("navbar");
					  if (x.style.display === "block") {
					      x.style.display="none";
					  } else {
					      x.style.display = "block";
					  }
					}

					function menuResize()
					{
					    if (window.outerWidth > 1300)
					        document.getElementById("navbar").style.display = "block";
                        else
					        document.getElementById("navbar").style.display = "none";
					}
					
					</script>
								
            <a href="#" onclick="menuFunction()">
                <div class="hamburger"></div>
			    <div class="hamburger"></div>
			    <div class="hamburger"></div>
            </a>

				
	      <nav id="navbar">
		        <ul>
			        <li><a class="menulinks" href="index.php" target="_parent">Homepage</a></li>
					<li><a class="menulinks" href="about.php" target="_parent" >About</a></li> 
			        <li><a class="menulinks" href="CanvasWithSave.php" target="_parent">Draw</a></li> 
			        <li><a class="menulinks" href="upload.php" target="_parent">Upload a drawing</a></li> 
			        <li><a class="menulinks" href="gallery.php" target="_parent">Gallery</a></li> 
					<li><a class="menulinks" href="contact.php" target="_parent" >Contact</a></li> 
		        </ul>
	        </nav>
	    </header>
    
    <main>    
	<br><br><h1 class="user_msg">Upload a drawing</h1><br>
	    
	 <h3 class="user_msg">Upload your drawing and wait for your mentor feedback</h3><b>
	 
  	<form id="reportForm" method ="post" action="upload.php" onsubmit="return validateAll()">

	<input class=".col-4" id="img" name='img' placeholder="drawing" type="file"/></p>

		<p><input class=".col-4" id="submit" name="submit" type="submit" value="שלח"></p>
		<br>
	
			<br><br>
    </form>
	
</main>
</body>

</html>

<script>
            function log_out(){
                window.location='logout.php';
            }
        </script>