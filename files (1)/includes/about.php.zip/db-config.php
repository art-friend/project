<?php

$mysqli = new mysqli("localhost","iscoralil","katlanim","iscorali_ART");
if($mysqli->connect_error) {
  exit('Error connecting to database'); //Should be a message a typical user could understand in production
}