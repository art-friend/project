<?php 
require_once "config.php";
session_start();

if(!isset($_SESSION['username'])) {

      $message = $_SESSION['message'];
      header("location: login.php");

}
$message = "";
   //check for any message
   if(isset($_SESSION['message'])) {

      $message = $_SESSION['message'];
      unset($_SESSION['message']);
   }
   if(isset($_REQUEST['logout'])) {
      
      session_destroy();
      header("location: login.php");
   }
   
$permission = array();
   
   if($_SESSION['user_role'] == "admin"){
      
         
   } else {
         
        
   }
   $pagefound = "No";
   foreach($permission as $findme) {
      if(stripos($_SERVER['REQUEST_URI'], $findme) != false) {
         $pagefound = "Yes";
      }
   }
   if($pagefound == "No") {
      //header("Location: wrong_level.php");
   // exit();
   }
   



