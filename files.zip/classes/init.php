<?php
  
require_once('user.php');
require_once('database.php');
require_once('config.php');
require_once('session.php');
require_once('password.php');
?>
